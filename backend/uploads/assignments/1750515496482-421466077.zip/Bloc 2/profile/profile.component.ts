import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {
  userId !: number;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.userId = parseInt(this.route.snapshot.paramMap.get('id') || '0');
    console.log(this.userId)
  }
}
