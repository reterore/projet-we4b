import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private admin = false;
  private realKey = 'secretKey'; // simulée comme venant du backend

  setAdminKey(inputKey: string): void {
    if (inputKey.localeCompare(this.realKey) == 1) {
      this.admin = true;
    }
  }

  isAdmin(): boolean {
    return this.admin;
  }
}
