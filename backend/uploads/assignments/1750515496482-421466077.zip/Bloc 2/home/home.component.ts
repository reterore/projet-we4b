import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
export class HomeComponent {
  key = '';

  constructor(private router: Router, private authService: AuthService) {}

  goToAdmin(): void {
    this.router.navigate(['/admin']);
  }

  activateAdmin(): void {
    this.authService.setAdminKey(this.key);
  }
}
